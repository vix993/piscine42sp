/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vnascime <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/15 16:14:11 by vnascime          #+#    #+#             */
/*   Updated: 2019/10/15 16:24:04 by vnascime         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putstr(char *str);

int		main()
{
	char str[] = "Living life\n";
	char str0[] = "Half way there, living on a prayer\n";

	ft_putstr(str);
	ft_putstr(str0);
}
